//
//  webservice_exercice_startApp.swift
//  webservice-exercice-start
//
//  Created by Maxime Britto on 03/09/2021.
//

import SwiftUI

@main
struct webservice_exercice_startApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
